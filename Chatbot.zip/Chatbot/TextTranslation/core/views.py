
from django.http.response import HttpResponseRedirect
from django.shortcuts import render

from googletrans import Translator
from gtts import gTTS
# import gtts
from gtts import lang
# from playsound import playsound
# from pydub import AudioSegment
# from pydub.playback import play
import playsound, os
from django.http import HttpResponse

import pyttsx3 # pip instal pyttsx3
# import datetime
# import speech_recognition as sr # pip install speechRecognition


global txt
global tr
global result

def translate_app(request):
	if request.method == "POST":
		global lang
		global txt
		global tr
		lang = request.POST.get("lang", None)
		# print('hello',lang)
		txt = request.POST.get("txt", None)
		# print('helo',txt)
		translator = Translator()
		tr = translator.translate(txt, dest=lang)
		

		return render(request, 'translate.html', {"result":tr.text})
	return render(request, 'translate.html')

def Text_to_speech(request):
	print("raghava")
	audio='C:\\Users\\spsoft\\Desktop\Chatbot\\TextTranslation\\sound\\Sample_voice.mp3'
	if os.path.isfile(audio):
		os.remove(audio)
	else:
		pass	
	if request.method == 'GET':
		print("raghava")
		translator = Translator()
		tr = translator.translate(txt, dest=lang)
		result=str(tr.text)
		print(result)
		speech = gTTS(text = result,slow=False)
		speech.save('./sound/Sample_voice.mp3')
		playsound.playsound('./sound/Sample_voice.mp3')

	return HttpResponseRedirect('/')

		