from django.urls import path
from . import views
from DJangoTextTranslation.settings import MEDIA_ROOT
from DJangoTextTranslation.settings import MEDIA_URL
from django.conf import settings
from django.conf.urls.static import static


urlpatterns=[
    path('',views.translate_app,name='trans'),
    path('Text_to_speech',views.Text_to_speech,name='speech')    
]

# if settings.DEBUG:
urlpatterns+= static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)